from django.http import HttpResponse
from django.shortcuts import render,redirect
from matplotlib.pyplot import title
from .models import Task

def home(request):
    if request.method == 'POST':
        title = request.POST['task'] 
        input = request.POST['description']
        Task.objects.create(task = title , description=input)
        return redirect('home')
    obj = Task.objects.all()
    context = {'tasks': obj}
    return render(request, 'home.html', context)

def delete_task(request, pk):
    obj = Task.objects.get(id=pk)
    obj.delete()
    return redirect('home')

def update_task(request, pk):
    obj = Task.objects.get(id=pk)
    previous_task = obj.task
    previous_description = obj.description
    if request.method == "POST":
        new_task = request.POST['task']
        new_description = request.POST['description']
        obj.task = new_task
        obj.description = new_description
        obj.save()
        return redirect('home')
    obj = Task.objects.all()
    context = {'tasks': obj, 'task' : previous_task, 'description' : previous_description}
    return render(request, 'home.html', context)


